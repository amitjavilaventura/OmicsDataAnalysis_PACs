#########################
###      DEannot      ###
#########################

#' @title DEannot
#' @author amitjavilaventura
#' 
#' @usage DiffExp(dataframe, pval = 0.05, log2FC = 1.5)
#' 
#' Function that takes a DESeq2 output and creates an extra column that tells if a gene is Downregulated, Upregulated or NotDE
#' 
#' @param dataframe dataframe. Output from DESeq2 with an extra DEG column. Columns: Geneid, baseMean, log2FoldChange, lfcSE, pvalue, padj, DEG.
#' @param pval numerical. p-value threshold used to call de DEGs. It is used to draw a dashed line in this value. Default: 0.05.
#' @param log2FC numerical. log2FC threshold (in absolute value) used to call the DEGs. It is used to draw two lines in this value (positive and negative). Default: 1.5.

DEannot <- function(dataframe, pval = 0.05, log2FC = 1.5) {
  
  #load packages
  require(dplyr)
  
  df <- dataframe %>% mutate(DEG = rep("NotDE", length(dataframe[,1])))
  
  df$DEG[which(df$log2FoldChange >= log2FC & df$padj <= pval)] <- "Upregulated" #Annotate UPregulated genes
  df$DEG[which(df$log2FoldChange <= -log2FC & df$padj <= pval)] <- "Downregulated" #Annotate DOWNregulated genes
  
  return(df)
}

############################
###      SubsetDEGs      ###
############################

#' @title subsetDegs
#' @author amitjavilaventura
#' 
#' @usage subsetDegs(dataframe, de = c("Upregulated", "Downregulated"))
#' 
#' Function that takes the output from DEannot() and separates the Downregulated, Upregulated or NotDE genes
#' 
#' @param dataframe dataframe. Output from DESeq2 with an extra DEG column. Columns: Geneid, baseMean, log2FoldChange, lfcSE, pvalue, padj, DEG.
#' @param de character vector of length 1 or 2. Name of the DE state. Default: c("Upregulated", "Downregulated")

subsetDegs <- function(dataframe, de = c("Upregulated", "Downregulated")) {
  
  #load packages
  require(dplyr)
  
  up   <- dataframe %>% filter(DEG == de[1]) %>% dplyr::select(Geneid)
  down <- dataframe %>% filter(DEG == de[2]) %>% dplyr::select(Geneid)
  
  list <- list(up   = up$Geneid,
               down = down$Geneid)
  
  return(list)
  
}

###########################
###      OverlapDE      ###
###########################

#' @title overlapDE
#' @author amitjavilaventura
#' 
#' @usage overlapDE(d1, d2)
#' 
#' Function that takes two vectors of gene names, makes the intersection and draws a VennDiagram
#' 
#' @param df1 character vector
#' @param df2 character vector
#' @param categories character vector of length 2. Name of the input categories (datasets) used for the intersection
#' @param color character vector of length 2. Colors of the circle and circumeference of the categories 1 and 2.

overlapDE <- function(d1, d2, categories = c("Category 1", "Category 2"), color = c("Red", "Blue")) {
  
  #load packages
  require(dplyr)
  require(VennDiagram)
  
  #make intersection
  int <- intersect(d1, d2)
  
  #draw venn diagram
  venn <- draw.pairwise.venn(area1 = length(d1), area2 = length(d2), cross.area = length(int),
                             category = categories, scaled = T, fill = color, alpha = 0.8, label.col = "Black")
  
  return(venn)
  
}

###########################
###      OverlapDE3     ###
###########################

#' @title overlapDE3
#' @author amitjavilaventura
#' 
#' @usage overlapDE3(d1, d2, d3)
#'

overlapDE3 <- function(d1, d2, d3, categories = c("Category 1", "Category 2", "Category 3"), color = c("Red", "Blue", "Green")) {
  
  #load packages
  require(dplyr)
  require(VennDiagram)
  
  #make intersection
  int12 <- intersect(d1, d2)
  int13 <- intersect(d1, d3)
  int23 <- intersect(d2, d3)
  
  int123 <- intersect(int12, d3)
  
  #draw venn diagram
  venn <- draw.triple.venn(area1 = length(d1), area2 = length(d2), area3 = length(d3), 
                           n12 = length(int12), n13 = length(int13), n23 = length(int23), n123 = length(int123),
                           category = categories, scaled = T, fill = color, alpha = 0.8, label.col = "Black")
  
  return(venn)
  
}

##############################
###     VOLCANO PLOT 2     ###
##############################

#' @title VolcanoPlot2
#' @author amitjavilaventura & dfernandezperez
#' 
#' @usage VolcanoPlot2(dataframe, xlim = c(-10,10), ylim = c(0,30), main = NULL, title_size = 9, labelSize = 7, labelColor = c("darkgreen", "red"), labelPos = 0, pval = 0.05, log2FC = 1.5, xlab = "log2(FC)", ylab = "-log10(pval)", axis_label_size = 7, axis_text_size = 7, point.color = c("darkgreen", "gray", "red"), legend_title = FALSE, legend_pos = "bottom", infinite = T)
#' 
#' Function that draws a volcano plot with DEGs. 
#' As input, it takes the output of DESeq2 after adding a DEG (look at DiffExp funtion) information column (Downregulated, Upregulated, NotDE). Columns: Geneid, baseMean, log2FoldChange, lfcSE, pvalue, padj, DEG.
#' It also counts the number of up and downregulated genes and writes them in the plot.
#'
#' @param dataframe dataframe. Output from DESeq2 with an extra DEG column. Columns: Geneid, baseMean, log2FoldChange, lfcSE, pvalue, padj, DEG.
#' @param xlim numerical of length 2. The limits of the x axis where the log2FC is plotted. Default: c(-10,10).
#' @param ylim numerical of length 2. The limits of the y axis where the -log10(adj_pval) is plotted.  Default: c(0,30).
#' @param main character. The title of the volcano plot. Default: NULL. 
#' @param title_size numerical. The size of the title. Default: 9. 
#' @param labelSize numerical. The size of the numbers of up and downregulated genes. Default: 7.
#' @param labelColor character of length 2. Colors of the numbers of downregulated and upregulated genes. Default: c("darkgreen", "red").
#' @param labelPos numerical. Position of the numbers of up and downregulated genes along the y axis. Default: 0.
#' @param pval numerical. p-value threshold used to call de DEGs. It is used to draw a dashed line in this value. Default: 0.05.
#' @param log2FC numerical. log2FC threshold (in absolute value) used to call the DEGs. It is used to draw two lines in this value (positive and negative). Default: 1.5.
#' @param xlab character. label of the X axis. Default: "log2(FC)".
#' @param ylab character. Label of the Y axis. Default: "-log10(pval)".
#' @param axis_label_size numerical. Size of the axis labels. Default: 7.
#' @param axis_text_size numerical. Size of the text in the axis. Default: 7.
#' @param point.color character of length 3. Colors of the downregulated, notDE and upregulated points. Default: c("darkgreen", "gray", "red")
#' @param legend_title logical. If FALSE, the title of the legend is not plotted. Default: FALSE.
#' @param legend_pos character. Position of the legend. One of: "bottom", "top", "right", "left", "none". Default: "bottom".
#' @param infinite logical. If TRUE, the points that are outside of the limits are plotted in the edges with different shapes. Default: TRUE.
#' @param degsLabel logical. If TRUE, the most differentially expressed genes are labelled. Default: FALSE.
#' @param degsLabelNum numerical. Number of most expressed genes to label in the plot. Default: 5.

VolcanoPlot2 <- function(dataframe, xlim = c(-10,10), ylim = c(0,30), main = NULL, title_size = 9, 
                         labelSize = 7, labelColor = c("darkgreen", "red"), labelPos = 0,
                         pval = 0.05, log2FC = 1.5, xlab = "log2(FC)", ylab = "-log10(pval)", axis_label_size = 7, axis_text_size = 7, 
                         point.color = c("darkgreen", "gray", "red"), legend_title = FALSE, legend_pos = "bottom", infinite = T,
                         degsLabel=F, degsLabelNum=5) {
  #load package ggplot2
  require(ggplot2)
  require(dplyr)

  df <- dataframe 
  
  #do transformations in case I want to show the points that are out of the axis limits
  if(infinite) { 
    df <- df %>% filter(padj != "NA")
    
    #transform the p-values that have a -log10pval greater than the ylim to 0, thus their -log10pval will be Inf.
    for(i in 1:length(df$padj)){   
      if((-log10(df$padj[i]) > ylim[2])){ 
        df$padj[i] <- 0 
      } 
    }
    
    #transform the log2FC that are bigger than the xlim to Inf and that are smaller to the xlim to -Inf
    for(i in 1:length(df$log2FoldChange)){ 
      if( df$log2FoldChange[i] > xlim[2] ){ 
        df$log2FoldChange[i] <- Inf 
      } 
      else if( df$log2FoldChange[i] < xlim[1] ){ 
        df$log2FoldChange[i] <- -Inf 
      }
    }
  }  
  
  #generate the graph with ggplot(), stablish the foldchange and pvalue to colour the DEGs and stablish the point format.
  if(!infinite){
    p <-  ggplot(data = df, aes(x = log2FoldChange, y = -log10(padj), colour = DEG) ) +
      geom_point(size = 1.5, shape = 16)
  }
  
  if(infinite) {
    p <- ggplot() +
      geom_point(data = df[which(df$padj != 0 & 
                                   df$log2FoldChange != Inf & 
                                   df$log2FoldChange != -Inf),], 
                 aes(x = log2FoldChange, y = -log10(padj), colour = DEG), size = 1.5, shape = 16) +
      
      geom_point(data = df[which(df$padj == 0),], aes(x = log2FoldChange,  y = -log10(padj), colour = DEG), size = 1.5, shape = 3) + 
      geom_point(data = df[which(df$log2FoldChange == Inf),], aes(x = log2FoldChange, y = -log10(padj), colour = DEG), size = 1.5, shape = 3) +
      geom_point(data = df[which(df$log2FoldChange == -Inf),], aes(x = log2FoldChange, y = -log10(padj), colour = DEG), size = 1.5, shape = 3)
  }
  
  #annotate the number of up and downregulated DEGs
  p <- p +
    annotate("text", label = sum(df$DEG == "Upregulated"), color = labelColor[2], y = labelPos, x = xlim[2], 
             vjust=0.5,hjust="inward", size = labelSize) +
    annotate("text", label = sum(df$DEG == "Downregulated"), color = labelColor[1], y = labelPos, x = xlim[1],
             vjust=0.5,hjust="inward", size = labelSize) + 
    
    #stablish a predefined theme
    theme_classic() +
    
    #write and format the graph title, can be nothing. 
    ggtitle(main) +
    theme(plot.title = element_text(face="bold", hjust = .5, size = title_size)) +
    
    #stablish the x and y axes ranges. 
    coord_cartesian(xlim = xlim, ylim = ylim) +
    
    #put an horizontal line in the -log10(pval) value and two vertival lines in the -logFC and logFC values. 
    geom_hline(yintercept = -log10(pval), linetype = 2) +
    geom_vline(xintercept = c(-log2FC, log2FC), linetype = 2) +
    
    #format the axis names and sizes
    xlab(xlab) + ylab(ylab) + theme(axis.title = element_text(size = axis_label_size)) +
    
    #format the color of the points
    scale_colour_manual(values=point.color) +
    
    #format the axis values
    theme(axis.text = element_text(size = axis_text_size)) +
    
    #decide the position of the legend (default: "bottom")
    theme(legend.position = legend_pos) 
  
  #decide if legend title is writen or not. Default: not writen.  
  if(legend_title==FALSE){
    p <- p + theme(legend.title = element_blank())
  }
  
  # Write names of the most upreg genes
  if(degsLabel==TRUE) {
    #load ggrepel
    require(ggrepel)
    
    # organaize and retrieve most upregulated and most downregulated genes
    df$abs_log2fc <- sqrt(df$log2FoldChange**2)
    df  <- df %>% dplyr::arrange(abs_log2fc)
    df2 <- rbind(tail(na.omit(df),degsLabelNum)) %>% as.data.frame()
    df  <- df %>% arrange(padj) 
    df2 <- rbind(df2, head(df, degsLabelNum))
    #put labels in the plot
    p <- p + geom_text_repel(data = df2, mapping = aes(x = log2FoldChange, y = -log10(padj), label = Geneid), size = 5, color = "Black")
    
  }
  
  #draw the graph.
  p
  
}


#######################
###     PCAPLOT2    ###
#######################

#########################
###     PCAPLOT 2     ###
#########################

# Modification of the R function pcaplot() from the R package pcaExplorer. 

# ----------------------------------------------------- #

#' Sample PCA plot for transformed data
#'
#' Plots the results of PCA on a 2-dimensional space
#'
#' @param x A \code{\link{DESeqTransform}} object, with data in \code{assay(x)},
#' produced for example by either \code{\link{rlog}} or
#' \code{\link{varianceStabilizingTransformation}}
#' @param intgroup Interesting groups: a character vector of
#' names in \code{colData(x)} to use for grouping
#' @param ntop Number of top genes to use for principal components,
#' selected by highest row variance
#' @param returnData logical, if TRUE returns a data.frame for further use, containing the
#' selected principal components and intgroup covariates for custom plotting
#' @param title The plot title
#' @param pcX The principal component to display on the x axis
#' @param pcY The principal component to display on the y axis
#' @param text_labels Logical, whether to display the labels with the sample identifiers
#' @param point_size Integer, the size of the points for the samples
#' @param ellipse Logical, whether to display the confidence ellipse for the selected groups
#' @param ellipse.prob Numeric, a value in the interval [0;1)
#'
#' @return An object created by \code{ggplot}, which can be assigned and further customized.
#'
#' @examples
#' dds <- makeExampleDESeqDataSet_multifac(betaSD_condition = 3,betaSD_tissue = 1)
#' rlt <- DESeq2::rlogTransformation(dds)
#' pcaplot(rlt, ntop=200)
#'
#' @export
pcaplot2 <- function(x, intgroup = "condition", ntop = 500, returnData = FALSE, title = NULL,
                     pcX = 1, pcY = 2, text_labels = TRUE, legend_title = FALSE,
                     point_size = 3, point_shape = 16,
                     ellipse = TRUE, ellipse.prob = 0.95) # customized principal components
{
  rv <- rowVars(assay(x))
  select <- order(rv, decreasing = TRUE)[seq_len(min(ntop,length(rv)))]
  pca <- prcomp(t(assay(x)[select, ]))
  
  percentVar <- pca$sdev^2/sum(pca$sdev^2)
  
  if (!all(intgroup %in% names(colData(x)))) {
    stop("the argument 'intgroup' should specify columns of colData(x)")
  }
  intgroup.df <- as.data.frame(colData(x)[, intgroup, drop = FALSE])
  group <- factor(apply(intgroup.df, 1, paste, collapse = " : "))
  d <- data.frame(PC1 = pca$x[, pcX], PC2 = pca$x[, pcY], group = group,
                  intgroup.df, names = colnames(x))
  colnames(d)[1] <- paste0("PC",pcX)
  colnames(d)[2] <- paste0("PC",pcY)
  
  if (returnData) {
    attr(d, "percentVar") <- percentVar[1:2]
    return(d)
  }
  
  # clever way of positioning the labels - worked good, then no need with ggrepel
  d$hjust <- ifelse((sign(d[,paste0("PC",pcX)])==1),0.9,0.1)# (1 + varname.adjust * sign(PC1))/2)
  
  g <- ggplot(data = d, aes_string(x = paste0("PC",pcX), y = paste0("PC",pcY), color = "group")) +
    geom_point(size = point_size, shape = point_shape) +
    xlab(paste0("PC",pcX,": ", round(percentVar[pcX] * 100,digits = 2), "% variance")) +
    ylab(paste0("PC",pcY,": ", round(percentVar[pcY] * 100,digits = 2), "% variance"))
  
  ## plot confidence ellipse
  # credit to vince vu, author of ggbiplot
  if(ellipse) {
    theta <- c(seq(-pi, pi, length = 50), seq(pi, -pi, length = 50))
    circle <- cbind(cos(theta), sin(theta))
    
    ell <- ddply(d, 'group', function(x) {
      if(nrow(x) <= 2) {
        return(NULL)
      }
      sigma <- var(cbind(x[[paste0("PC",pcX)]], x[[paste0("PC",pcY)]]))
      mu <- c(mean(x[[paste0("PC",pcX)]]), mean(x[[paste0("PC",pcY)]]))
      ed <- sqrt(qchisq(ellipse.prob, df = 2))
      data.frame(sweep(circle %*% chol(sigma) * ed, 2, mu, FUN = '+'),
                 groups = x$group[1])
    })
    # names(ell)[1:2] <- c('xvar', 'yvar')
    if(nrow(ell)>0) {
      g <- g + geom_path(data = ell, aes_string(x="X1",y="X2",color = "groups", group = "groups"))
    }
  }
  
  if(text_labels)
    g <- g + geom_label_repel(mapping = aes_string(label="names",fill="group"),
                              color="white", show.legend = TRUE) 
  if(!is.null(title)) g <- g + ggtitle(title)
  g <- g + theme_bw()
  # changing the legend title
  if(legend_title == FALSE) {g <- g + theme(legend.title=element_blank())}
  # as in http://www.huber.embl.de/msmb/Chap-Graphics.html
  # "well-made PCA plots usually have a width that’s larger than the height"
  g <- g + coord_fixed()
  g <- g + theme(plot.title = element_text(face = "bold"))
  g
}
